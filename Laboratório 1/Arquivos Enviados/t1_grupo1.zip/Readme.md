UNIVERSIDADE FEDERAL DO RIO GRANDE DO SUL - Semestre 2022/02

Trabalho 1 - Busca em Grafos

Grupo 1
Andrei Pochmann Koenich - Cartão 00308680 - Turma A
Jean Smaniotto Argoud   - Cartão 00275602 - Turma B
Willian Nunes Reichert  - Cartão 00134090 - Turma B

Bibliotecas:
utilizamos apenas bibliotecas nativas do Python 3.8.

Dados de execução dos algoritmos para a entrada "2_3541687":
esses dados podem ser coletados ao executar diretamente o arquivo solucao.py.
Nós expandidos --------------------------------------------------
BFS          : 101841 nós
DFS          :   5477 nós
A* Hamming   :  13498 nós
A* Manhattan :   1598 nós
Custo -----------------------------------------------------------
BFS          :   23 movimentos
DFS          : 5329 movimentos
A* Hamming   :   23 movimentos
A* Manhattan :   23 movimentos
Tempo de execução -----------------------------------------------
BFS          : 2030.100 ms
DFS          :   21.570 ms
A* Hamming   :  159.690 ms
A* Manhattan :   25.722 ms
